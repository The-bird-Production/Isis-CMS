const fs = require("fs");
const request = require("request");

function download(url, dest, cb) {
  const file = fs.createWriteStream(dest);
  const sendReq = request.get(url);
  sendReq.on("response", (response) => {
    if (response.statusCode !== 200) {
      return cb("Response status was " + response.statusCode);
    }
  });
  sendReq.on("error", (err) => {
    fs.unlink(dest);
    cb(err.message);
  });
  sendReq.pipe(file);
  file.on("finish", () => {
    file.close(cb);
  });
  file.on("error", (err) => {
    fs.unlink(dest);
    cb(err.message);
  });
}

module.exports = download