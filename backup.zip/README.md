
# Isis CMS

Isis CMS is an open source CMS based on express js technology with NodeJS. The CMS uses MySQL as the database engine.


## Intro
Hello my name is Faynix I'm a very young node js full stack developer. In this project i tried to create a simple and convenient fast cms using node js. Sorry for my bad english I'm french 

## Documentation

[Documentation (GitBook only in french for now)](https://the-bird-production.gitbook.io/isis-cms-fr-docs/)


## Roadmap

- Add static pages system 

- Add update system for themes and plugins 


## Used By

This project is used by the following companies:

- The bird production
- Au pied du Morclan 
- Partage ta Fiche 


## Authors

- [@Faynix-code](https://www.github.com/Faynix-code)


![Logo](https://i.imgur.com/b0EQ8TS.png)

