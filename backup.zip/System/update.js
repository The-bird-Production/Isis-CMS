const { exec } = require("child_process");
const env = require("../var");
const config = require("../config.json");
const colors = require("colors/safe");
colors.enable();
const AdmZip = require("adm-zip");

//Database Migration
const knex = require("knex");
const knex_conf = require("../knexfile");
const migrate_knex = knex(knex_conf.production);

//Process manager 

const restart = require('../Functions/RestartApp');
const download = require('../Functions/Download');




async function migrate_db() {
  console.log(colors.green(" Start migrating Database..."));

  try {
    await migrate_knex.migrate.latest({
      directory: env.dirname + "/migrations/",
    });
    console.log(colors.green(" Database migrated successfully!"));
  } catch (error) {
    console.error(colors.red("Error during database migration " + error));
  } finally {
    await migrate_knex.destroy();
  }
}

async function updateFiles() {
  try {
    const url =
      "https://update.isis-cms.thebirdproduction.fr/manager/version/download/" +
      config.update_key;

      download(url, env.dirname+ "/update/temp.zip", (err) => {
        if (!err) {
          const zip = new AdmZip(env.dirname + "/update/temp.zip");
          zip.extractAllTo(env.dirname, true);
        }else {
          console.error("Erreur lors du téléchargement des fichiers : "+err);
          throw err;

        }
      })

    
    
    }catch(e){
      console.log("Erreur lors de la mis à jour des fichiers :  "+ e)
      throw err; 
      
    }
}

function restart_app() {
  return new Promise((resolve, reject) => {
    exec("npm install", (error, stdout, stderr) => {
      if (error) {
        console.error("Erreur lors de l'installation des dépendances", error);
      }
      reject(error);
    });

    restart()
    .then(() => resolve())
    .catch(reject());

    


  });
}

async function update() {
  try {
    console.log("Update Starting")
    await updateFiles();
    console.log("Updating files Done")
    await migrate_db();
    console.log("Migrate db Done")
    await restart_app();
    console.log("Restart app Done")
  } catch (error) {
    console.error("New error during update", error);
    return error
  }
}

exports.update = update;
